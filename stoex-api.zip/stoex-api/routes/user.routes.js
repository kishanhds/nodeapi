const express = require("express");
const pool = require("../db/db");

const router = express.Router();

/* GET ALL USERS */
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, name, email, created_at FROM users ORDER BY id ASC"
    );

    res.json({
      count: result.rows.length,
      users: result.rows,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
