const express = require("express");
const pool = require("../db/db"); // your postgres connection
const router = express.Router();

/* ================= TOTAL USERS ================= */
router.get("/total", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT COUNT(*) AS total_users FROM users"
    );

    res.status(200).json({
      totalUsers: parseInt(result.rows[0].total_users),
    });
  } catch (error) {
    console.error("Total users error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
